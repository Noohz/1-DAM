package recupExamen;

public class Medico {
	
	// Atributos
	private int numColegiado;
	private String especialidad;
	private final static double SUELDO_MINIMO = 2000;
	private double sueldoAtributo;
	CentroSalud c1;
	
	public Medico () {
		
	}
	
	public Medico (int numColegiado, String especialidad, double sueldoAtributo, CentroSalud c1) {
		this.numColegiado = numColegiado;
		this.especialidad = especialidad;
		this.sueldoAtributo = sueldoAtributo;
		
	}

	public int getNumColegiado() {
		return numColegiado;
	}

	public void setNumColegiado(int numColegiado) {
		this.numColegiado = numColegiado;
	}

	public String getEspecialidad() {
		return especialidad;
	}

	public void setEspecialidad(String especialidad) {
		this.especialidad = especialidad;
	}

	public double getSueldoAtributo() {
		return sueldoAtributo;
	}

	public void setSueldoAtributo(double sueldoAtributo) {
		this.sueldoAtributo = sueldoAtributo;
	}

	public CentroSalud getC1() {
		return c1;
	}

	public void setC1(CentroSalud c1) {
		this.c1 = c1;
	}

	public static double getSueldoMinimo() {
		return SUELDO_MINIMO;
	}
	
	public void mostrar () {
		System.out.println("El número de colegiado es: " +this.numColegiado+ ".\nEl médico está especializado en : " +this.especialidad+ 
				".\nEl sueldo del médico es: " +this.sueldoAtributo);
		
		System.out.println("# - Datos del centro donde trabaja el médico - #");
		System.out.println(this.c1.toString());
		
	}
	
	public void calcularSueldo () {
		
		if (especialidad.equalsIgnoreCase("cirujano") || especialidad.equalsIgnoreCase("investigador")) {
			
			sueldoAtributo = SUELDO_MINIMO + 400;
			
		} else if (especialidad.equalsIgnoreCase("cabecera") || especialidad.equalsIgnoreCase("pediatría")) {
			
			sueldoAtributo = SUELDO_MINIMO + 200;
			
		}
	}
	
}
