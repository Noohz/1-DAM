package recupExamen;

import java.util.*;

public class Receta {
	
	// Atributos
	private int numRecetas = 0;
	private String codReceta;
	Medico m1;
	
	public Receta () {
		
	}
	
	public Receta (int numRecetas, String codReceta, Medico m1) {
		this.numRecetas = numRecetas;
		this.codReceta = codReceta;
	}

	public int getNumRecetas() {
		return numRecetas;
	}

	public void setNumRecetas(int numRecetas) {
		this.numRecetas = numRecetas;
	}

	public String getCodReceta() {
		return codReceta;
	}

	public void setCodReceta(String codReceta) {
		this.codReceta = codReceta;
	}

	public Medico getM1() {
		return m1;
	}

	public void setM1(Medico m1) {
		this.m1 = m1;
	}
	
	public void mostrar () {
		
		System.out.println("Número de recetas dispensadas : " +this.numRecetas+ ".\nEl código de la receta es: " +this.codReceta);
		
		System.out.println("# - Información del Médico - #");
		m1.mostrar();
		
	}
	
	public static void crearReceta (String codReceta, int numRecetas) {
		
		String priLetra;
		String ultiLetra;
		Scanner sc = new Scanner (System.in);
		
		System.out.println("Introduce la primera letra de tu nombre: ");
		priLetra = sc.nextLine();
		
		System.out.println("Introduce la ultima letra de tu nombre: ");
		ultiLetra = sc.nextLine();
		
		codReceta = codReceta.concat(priLetra + ultiLetra + numRecetas);
		
		numRecetas++;
		
		sc.close();
	}
}
