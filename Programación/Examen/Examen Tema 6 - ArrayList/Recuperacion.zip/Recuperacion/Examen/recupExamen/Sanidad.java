package recupExamen;

import java.util.*;

public class Sanidad {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		int opcion;
		Receta r1;
		
		ArrayList<Sanidad> principal ;
		
		do {
			
			System.out.println("# - MENU - #");
			System.out.println("1.- Generar recera.");
			System.out.println("2.- Mostrar recetas.");
			System.out.println("3.- Borrar receta.");
			System.out.println("4.- Buscar médico.");
			System.out.println("5.- Salir.");
			opcion = sc.nextInt();
			sc.nextLine();
			
				switch (opcion) {
				
					case 1:
						//generarReceta(principal);
						break;
					case 2:
						//mostrarReceta();
						break;
					case 3:
						//borrarReceta();
						break;
					case 4:
						//buscarMedico();
						break;
					case 5:
						break;
					default:
						System.err.println("Opción no válida...");
				}
			
		} while (opcion != 5);
		
	}

	
	public static void generarReceta (ArrayList<Sanidad> principal) {
		
		
		
	}
	
	public static void mostrarReceta (ArrayList<Sanidad> principal) {
		
		
		
	}

	public static void borrarReceta (ArrayList<Sanidad> principal, Receta r1) {
	
		Scanner brsc = new Scanner (System.in);
		String cod;
		
		System.out.println("Introduce el código de la receta a eliminar: ");
		cod = brsc.nextLine();
		
		if (r1.getCodReceta().equalsIgnoreCase(cod)) {
			principal.remove(cod);
		}
		
		
	
	}
	
}
