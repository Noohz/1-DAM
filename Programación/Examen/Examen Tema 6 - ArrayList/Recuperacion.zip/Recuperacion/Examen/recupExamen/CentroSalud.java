package recupExamen;

public class CentroSalud {
	
	// Atributos
	private String dirCentro;
	private int numMaxMedicos;
	
	public CentroSalud () {
		
	}
	
	public CentroSalud (String dirCentro, int numMaxMedicos) {
		this.dirCentro = dirCentro;
		this.numMaxMedicos = numMaxMedicos;
	}

	public String getDirCentro() {
		return dirCentro;
	}

	public void setDirCentro(String dirCentro) {
		this.dirCentro = dirCentro;
	}

	public int getNumMaxMedicos() {
		return numMaxMedicos;
	}

	public void setNumMaxMedicos(int numMaxMedicos) {
		this.numMaxMedicos = numMaxMedicos;
	}

	public String toString() {
		return "Dirección del centro de salud: " + dirCentro + "\nNúmero máximo de médicos que trabajan en él: " + numMaxMedicos;
		}
	
	
	
}
