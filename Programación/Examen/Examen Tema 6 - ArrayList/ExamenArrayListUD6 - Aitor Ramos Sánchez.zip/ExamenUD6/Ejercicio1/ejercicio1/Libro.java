package ejercicio1;

/**
 * 
 * @author Aitor Ramos Sánchez
 *
 */

import java.util.*;

public class Libro {

	// Atributos
	
	private String nombre;
	private int anioCreacion;
	private Autor a1;
	private static final int CATALOGACION = 18;
	
	/**
	 * Constructor por defecto.
	 */
	public Libro () {
		
	}
	
	/**
	 * Constructor parametrizado.
	 * @param nombre -> Almacena el nombre del libro.
	 * @param anioCreacion -> Almacena el año de creacion del libro.
	 */
	public Libro (String nombre, int anioCreacion, String nombreCompleto, String lugarNacimiento) {
		this.nombre = nombre;
		this.anioCreacion = anioCreacion;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getAnioCreacion() {
		return anioCreacion;
	}

	public void setAnioCreacion(int anioCreacion) {
		this.anioCreacion = anioCreacion;
	}

	public Autor getA1() {
		return a1;
	}

	public void setA1(Autor a1) {
		this.a1 = a1;
	}

	public static int getCatalogacion() {
		return CATALOGACION;
	}
	
	public void Mostrar () {
		System.out.println("El nombre del libro es: " +this.getNombre());
		System.out.println("El año de creación del libro es: " +this.getAnioCreacion());
		System.out.println("El nombre del autor del libro es: " +this.a1.nombreCompleto);
		System.out.println("El lugar de nacimiento de nacimiento del autor del libro es: " +this.a1.getLugarNacimiento());
		System.out.println("El código de catalogación es: " +Libro.getCatalogacion());
	}
	
	public void Genero () {
		Scanner sc = new Scanner (System.in);
		String generoLit;
		
		System.out.print("Introduce un género literario: ");
		generoLit = sc.nextLine();
		
		if (generoLit.equalsIgnoreCase("Narrativo")) {
			System.out.println("El género es: Novela.");
		} else if (generoLit.equalsIgnoreCase("Relato")) {
			System.out.println("El género es: Cuento.");
		} else if (generoLit.equalsIgnoreCase("Didactico")) {
			System.out.println("El género es: Ensayo.");
		} else if (generoLit.equalsIgnoreCase("Dramatico")) {
			System.out.println("El género es: Teatro.");
		} else {
			System.err.println("Error con el género narrativo...");
		}
		
		sc.close();
	}
	
}
