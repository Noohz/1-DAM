package ejercicio1;

/**
 * 
 * @author Aitor Ramos Sánchez
 *
 */

public class Autor {

	String nombreCompleto;
	private String lugarNacimiento;
	
	
	public Autor () {
		
	}
	
	public Autor (String nombreCompleto, String lugarNacimiento) {
		this.nombreCompleto = nombreCompleto;
		this.lugarNacimiento = lugarNacimiento;
	}

	public String getNombreCompleto() {
		return nombreCompleto;
	}

	public void setNombreCompleto(String nombreCompleto) {
		this.nombreCompleto = nombreCompleto;
	}

	public String getLugarNacimiento() {
		return lugarNacimiento;
	}

	public void setLugarNacimiento(String lugarNacimiento) {
		this.lugarNacimiento = lugarNacimiento;
	}
	
	public void Mostrar () {
		System.out.println("El nombre completo del Autor es: " +this.nombreCompleto);
		System.out.println("El lugar de nacimiento del Autor es: " +this.lugarNacimiento);
	}
	
	public void comprobarNacimiento () {
		
		boolean comprobacion;
		
		if (this.getLugarNacimiento().equalsIgnoreCase(lugarNacimiento)) {
			
			comprobacion = true;
			
		} else {
			
			comprobacion = false;
			
		}
		
		System.out.println("Coincide el nombre del autor? " +comprobacion);
		
	}
}
