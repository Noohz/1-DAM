package ejercicio1;

import java.lang.reflect.Array;
import java.util.*;

/**
 * 
 * @author Aitor Ramos Sánchez.
 *
 */

public class Biblioteca {

	public static void main(String[] args) {
		
		ArrayList<Libro> libros = new ArrayList<>();

		Scanner main = new Scanner (System.in);
		
		int opcion;
		
		do {
			
			System.out.println("# ** MENU ** #");
			System.out.println("1.- Insertar libro.");
			System.out.println("2.- Mostrar libros.");
			System.out.println("3.- Mostrar autores nacidos en Navalmoral.");
			System.out.println("4.- Buscar libro por nombre.");
			System.out.println("Para salir introduce '-1'.");
			System.out.print("Opcion: ");
			opcion = main.nextInt();
			main.nextLine();
			
			switch (opcion) {
				case 1:
					insertarLibro(libros);
					break;
				case 2:
					mostrarLibro(libros);
					break;
				case 3:
					mostrarAutores(libros);
					break;
				case 4:
					buscarLibro(libros);
					break;
				case -1:
					break;
				default:
					System.err.println("La opción introducida es invalida...");
			}
			
			
		} while (opcion != -1);		
	}

	public static void insertarLibro (ArrayList<Libro> libros) {
		Scanner insLibro = new Scanner (System.in);
		
		String nombLibro;
		int anioCreacionLibro;
		String nombreAutorLibro;
		String lugarNacimientoAutorLibro;
		String generoLitLibro;
		
		System.out.println("Introduce el nombre del libro: ");
		nombLibro = insLibro.nextLine();
		
		System.out.println("Introduce el año de creación del libro: ");
		anioCreacionLibro = insLibro.nextInt();
		insLibro.nextLine();
		
		System.out.println("Introduce el nombre del Autor del libro: ");
		nombreAutorLibro = insLibro.nextLine();
		
		System.out.println("Introduce el lugar de nacimiento del Autor del libro: ");
		lugarNacimientoAutorLibro = insLibro.nextLine();
		
		Libro libro = new Libro (nombLibro, anioCreacionLibro, nombreAutorLibro, lugarNacimientoAutorLibro);
		
		if (nombLibro.isBlank() || nombreAutorLibro.isBlank() || lugarNacimientoAutorLibro.isBlank()) {
			System.err.println("Los campos deben ser completados..");
		} else {
			libros.add(libro);
			System.out.println("\nLibro añadido correctamente..\n");
		}
		
	}
	
	public static void mostrarLibro (ArrayList<Libro> libros) {
		
		Iterator<Libro> it = libros.iterator();
		
		if (it.hasNext()) {
			System.out.println(it.next() + "\n");			
		}
		
	}
	
	public static void mostrarAutores (ArrayList<Libro> libros) {
		
		Autor a = new Autor ();
		int cont = 0;
		
			if (a.getLugarNacimiento().equalsIgnoreCase("Navalmoral")) {
				libros.get(cont);
				cont++;
			} else {
				System.err.println("No se ha encontrado ningún libro con ese lugar de nacimiento...");
			}
		
		
	}
	
	public static void buscarLibro (ArrayList<Libro> libros) {
		
		for (Libro x: libros) {
			if (x.getNombre().equalsIgnoreCase("La chica de nieve")) {
				x.Genero();
			}
		}
		
	}
	
}
