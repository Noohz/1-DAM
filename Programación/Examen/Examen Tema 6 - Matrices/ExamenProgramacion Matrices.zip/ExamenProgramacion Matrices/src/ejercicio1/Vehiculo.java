package ejercicio1;

public class Vehiculo {
	private final static double IVA = 8;
	private String matricula;
	private int numPlazas;
	private int agnoFabricacion;
	double precioSinIva;
	private double precioFinal;

	public Vehiculo() {

	}

	public Vehiculo(String matricula, int plazas, int agno, double precioSinIva) {
		this.matricula = matricula;
		this.numPlazas = plazas;
		this.precioSinIva = precioSinIva;
		this.agnoFabricacion = agno;
		this.precioFinal = precioFinal(precioSinIva);
	}

	public static double precioFinal(double precioSinIva) {
		double valorRetorno = 0;
		valorRetorno = (precioSinIva * IVA) / 100;
		return valorRetorno;
	}

	public String toString() {
		return " matricula: \n" + matricula + ",\nnumPlazas :\n" + numPlazas + ",\nañoFabricacion:\n"
				+ agnoFabricacion + "\nprecioSinIva: \n " + precioSinIva + "\nprecioFinal: \n" + precioFinal;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public int getNumPlazas() {
		return numPlazas;
	}

	public void setNumPlazas(int numPlazas) {
		this.numPlazas = numPlazas;
	}

	public int getAgnoabricacion() {
		return agnoFabricacion;
	}

	public void setAgnoFabricacion(int agnoFabricacion) {
		this.agnoFabricacion = agnoFabricacion;
	}

	public double getPrecioSinIva() {
		return precioSinIva;
	}

	public void setPrecioSinIva(double precioSinIva) {
		this.precioSinIva = precioSinIva;
	}

	public double getPrecioFinal() {
		return precioFinal;
	}

	
	public void setPrecioFinal(double precioFinal) {
		this.precioFinal = precioFinal;
	}
	
	

}
