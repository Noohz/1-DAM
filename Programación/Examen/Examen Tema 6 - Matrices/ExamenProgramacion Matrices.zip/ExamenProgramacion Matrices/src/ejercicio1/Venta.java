package ejercicio1;

public class Venta {
	private static int totalVentas = 0;
	private String nombreComprador;
	Vehiculo vehiculo;

	public Venta() {
		totalVentas++;
	}

	public Venta(String nombre, Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
		this.nombreComprador = nombre;
		totalVentas++;
	}

	public void mostrar() {
		System.out.println("Nombre del comprador \n" + this.nombreComprador);
		System.out.println(vehiculo.toString());
	}

	/**
	 * @return nombreComprador -> Devuelve un * * con el valor de nombreComprador
	 */
	public String getNombreComprador() {
		return nombreComprador;
	}

	/**
	 * @param nombreComprador nombreComprador -> Define el valor * * que tendrá
	 *                        nombreComprador
	 */
	public void setNombreComprador(String nombreComprador) {
		this.nombreComprador = nombreComprador;
	}

	/**
	 * @return totalVentas -> Devuelve un * * con el valor de totalVentas
	 */
	public static int getTotalVentas() {
		return totalVentas;
	}

}
