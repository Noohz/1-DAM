package ejercicio1;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * 
 * @author David H
 *
 */
public class Main {
	private static final int SALIR = 0;

	public static void main(String[] args) {
		Venta[] venta = new Venta[10];
		Scanner sc = new Scanner(System.in);
		int opcion = -1;

		do {
			try {
				System.out.println("***** 1. Insertar venta *****");
				System.out.println("***** 2. Mostrar ventas realizadas *****");
				System.out.println("***** 3. Buscar venta por comprador*****");
				System.out.print("--->");
				opcion = sc.nextInt();
				sc.nextLine();
				switch (opcion) {
				case 0:
					break;
				case 1:
					insertarVenta(venta, sc);
					break;
				case 2:
					mostrarVentas(venta);
					break;
				case 3:
					ventaPorComprador(venta, sc);
					break;
				default:
					System.err.println("Opción no disponible");
				}

			} catch (InputMismatchException e) {
				System.err.println("Opción no válida");
				sc.nextLine();
			}
		} while (opcion != SALIR);

	}

	public static void insertarVenta(Venta[] venta, Scanner sc) throws InputMismatchException {
		String comprador;
		String matriculaVehiculo;
		int plazas;
		int agnoFabricacion;
		double precioVehiculo;
		if (Venta.getTotalVentas() < venta.length) {
			System.out.println("Introduce nombre del comprador: ");
			comprador = sc.nextLine();
			System.out.println("Introduce Matrícula del vehículo: ");
			matriculaVehiculo = sc.nextLine();
			System.out.println("Introduce número de plazas : ");
			plazas = sc.nextInt();
			sc.nextLine();
			System.out.println("Introduce año fabricación: ");
			agnoFabricacion = sc.nextInt();
			sc.nextLine();
			System.out.println("Introduce precio del vehículo: ");
			precioVehiculo = sc.nextDouble();
			sc.nextLine();

			venta[Venta.getTotalVentas()] = new Venta(comprador,
					new Vehiculo(matriculaVehiculo, plazas, agnoFabricacion, precioVehiculo));

		} else {
			System.err.println("No puedes añadir más ventas al sistema");
		}
	}

	public static void mostrarVentas(Venta[] venta) {
		for (int i = 0; i < Venta.getTotalVentas(); i++) {
			venta[i].mostrar();
		}
	}

	public static void ventaPorComprador(Venta[] venta, Scanner sc) {
		String comprador;
		boolean verificar = false;
		int cont = 0;
		System.out.println("Introduce nombre de comprador");
		comprador = sc.nextLine();
		while (cont < Venta.getTotalVentas() && verificar == false) {
			if (venta[cont].getNombreComprador().equalsIgnoreCase(comprador)) {
				venta[cont].mostrar();
				verificar = true;
			}
			cont++;
		}
		if (verificar == false) {
			System.err.println("No se encontró comprador");
		}
	}

}
