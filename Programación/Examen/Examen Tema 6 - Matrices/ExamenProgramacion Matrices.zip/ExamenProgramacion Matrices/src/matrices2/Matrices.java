package matrices2;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Matrices {

	public static void main(String[] args) {
		try {
			Scanner sc = new Scanner(System.in);
			 int [][] matriz = rellenarMatriz(sc);
			mostrarMatriz(matriz);
			System.out.println("Este es el valor mayor de la matriz: " + valorMayor(matriz));
			System.out.println();
		} catch (InputMismatchException e) {
			System.out.println("Datos no válidos");
		}

	}

	public static int[][] rellenarMatriz(Scanner sc) throws InputMismatchException {
		int filas, columnas;
		System.out.println("Introduce número de filas: ");
		filas = sc.nextInt();
		sc.nextLine();
		System.out.println("Introduce número columnas");
		columnas = sc.nextInt();
		sc.nextLine();
		int[][] matriz = new int[filas][columnas];
		for (int i = 0; i < matriz.length; i++) {
			for (int b = 0; b < matriz[0].length; b++) {
				System.out.println("Introduce número:");
				matriz[i][b] = sc.nextInt();
				sc.nextLine();
			}
		}
		return matriz;
	}

	public static void mostrarMatriz(int[][] matriz) {
		for (int i = 0; i < matriz.length; i++) {
			for (int b = 0; b < matriz[0].length; b++) {
				System.out.printf(" | %d | ", matriz[i][b]);
			}
			System.out.println();
		}
	}

	public static int valorMayor(int[][] matriz) {
		int mayor = 0;
		for (int i = 0; i < matriz.length; i++) {
			for (int b = 0; b < matriz[0].length; b++) {
				if (matriz[i][b] > mayor) {
					mayor += matriz[i][b];
				}
			}
		}
		return mayor;
	}

}
